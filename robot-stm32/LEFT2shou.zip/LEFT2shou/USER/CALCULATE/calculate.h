#ifndef __CALCULATE_H_
#define __CALCULATE_H_

#include "sys.h"

typedef struct PID
{
	int    SetPoint; 			//  �趨Ŀ�� Desired Value
	long   SumError;			//	����ۼ� 
		
	double  Proportion;     //  �������� Proportional Const
	double  Integral;       //  ���ֳ��� Integral Const
	double  Derivative;     //  ΢�ֳ��� Derivative Const

	int LastError;         	//  Error[-1]
	int PrevError;            //  Error[-2]

} PID;
extern int IncPIDCalc(PID *sptr,int NextPoint);
extern float LocPIDCalc(PID *sptr,int NextPoint);

extern void Motor1SpeedContrl(void);
extern void Motor2SpeedContrl(void);
extern void Motor3SpeedContrl(void);


extern float g_fSpeedGive;
extern float g_fM1Speed,g_fM1ControlIntegral,g_fM1ControlOutOld,g_fM1ControlOutNew;
extern float g_fM2Speed,g_fM2ControlIntegral,g_fM2ControlOutOld,g_fM2ControlOutNew;
extern float g_fM3Speed,g_fM3ControlIntegral,g_fM3ControlOutOld,g_fM3ControlOutNew;

extern float carspeed;

#define err_max 300
#define optical_encoder_constant 512
#define speed_control_period 10
#define CAR_SPEED_CONSTANT 0.049    //1000/optical_encoder_constant/speed_control_period/4

#define M1_CONTR0L_P 1.5
#define M1_CONTR0L_I 0.1
#define M1_CONTR0L_D 0.1

#define M2_CONTR0L_P 1.5
#define M2_CONTR0L_I 0.1
#define M2_CONTR0L_D 0.1

#define M3_CONTR0L_P 1.5
#define M3_CONTR0L_I 0.1
#define M3_CONTR0L_D 0.1

#define VoltageToDuty 60

#define CAR_SPEED_SET   64


#endif
