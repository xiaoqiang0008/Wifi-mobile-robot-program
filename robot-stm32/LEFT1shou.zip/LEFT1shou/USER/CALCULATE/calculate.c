#include "calculate.h"
/* ========================================================================= */
/* Project Name  : STM32F103RCT6_Digital_PID	            			     */
/* File Name     : calculate.c												 */
/* Description   : Digital PID Speed Controller for Motor Drive Applications */
/*                 Using STM32F103RCT6                             		     */
/* Processor     : STM32F103RCT6											 */
/* Tools	     : MDK IDE V5 or later version				         */
/* ========================================================================= */
float g_fSpeedGive;
float g_fM1Speed=0,g_fM1ControlIntegral=0,g_fM1ControlOutOld=0,g_fM1ControlOutNew=0;
float g_fM2Speed=0,g_fM2ControlIntegral=0,g_fM2ControlOutOld=0,g_fM2ControlOutNew=0;
float g_fM3Speed=0,g_fM3ControlIntegral=0,g_fM3ControlOutOld=0,g_fM3ControlOutNew=0;
//============================================================= 
// ----Function: IncPIDCalc() 
// ------Syntax: int IncPIDCalc(unsigned int NextPoint);
// -Description: Increment Digital PID calculate
// -------Notes: Basic Increment Digital PID
// --parameters: Next Point
// -----returns: increase controls parameter
//=============================================================
int IncPIDCalc(PID *sptr,int NextPoint)
{
	int iError, iIncpid;
	char  Integral_constant=1;
	
	float  speed_get;
	speed_get=(float)NextPoint*CAR_SPEED_CONSTANT;
    if((iError-sptr->LastError)>err_max)
	{
		Integral_constant=0;
	}
	iError = sptr->SetPoint - speed_get;
 
	iIncpid = sptr->Proportion * (iError-sptr->LastError)                    //iError=E[0]
            + sptr->Integral   * iError	*Integral_constant    			     //sptr->LastError=E[-1]
            + sptr->Derivative * (iError-2*sptr->LastError+sptr->PrevError); //sptr->PrevError=E[-2]

	sptr->PrevError = sptr->LastError;
	sptr->LastError = iError;
	
	return(-iIncpid);
}

//============================================================= 
// ----Function: LocPIDCalc() 
// ------Syntax: unsigned int locPIDCalc(unsigned int NextPoint);
// -Description: Location Digital PID calculate
// -------Notes: Basic Location Digital PID
// --parameters: Next Point
// -----returns: Location controls parameter
//=============================================================
float LocPIDCalc(PID *sptr,int NextPoint)
{
    register float  iError,dError;
	
	iError = sptr->SetPoint - NextPoint;      	// ƫ��
	sptr->SumError += iError;					// ����
	dError = iError - sptr->LastError; 			// ��ǰ΢��
	sptr->LastError = iError;

	return(sptr->Proportion * iError           	// ������
           + sptr->Integral * sptr->SumError 	// ������
           + sptr->Derivative * dError);
}

//=============================================//
//	*END*
//=============================================//

void Motor1SpeedContrl(void)
{
	float fDelta;
	float fP,fI;
	float fCarSpeed;
	fCarSpeed=g_fM1Speed;
	fCarSpeed*=CAR_SPEED_CONSTANT;
	fDelta=g_fSpeedGive-fCarSpeed;
	fP=fDelta*M1_CONTR0L_P;
	fI=fDelta*M1_CONTR0L_I;
	g_fM1ControlIntegral+=fI;
	g_fM1ControlOutNew=g_fM1ControlOutOld+fP+g_fM1ControlIntegral;
    if(g_fM1ControlOutNew>=120)	{g_fM1ControlOutNew=120;}
	if(g_fM1ControlOutNew<=0)	{g_fM1ControlOutNew=0;}
	TIM3->CCR1=(int)(g_fM1ControlOutNew*VoltageToDuty);
	g_fM1ControlOutOld=g_fM1ControlOutNew;
	
}
void Motor2SpeedContrl(void)
{
	float fDelta;
	float fP,fI;
	float fCarSpeed;
	fCarSpeed=g_fM2Speed;
	fCarSpeed*=CAR_SPEED_CONSTANT;
	fDelta=g_fSpeedGive-fCarSpeed;
	fP=fDelta*M2_CONTR0L_P;
	fI=fDelta*M2_CONTR0L_I;
	g_fM2ControlIntegral+=fI;
	
	g_fM2ControlOutNew=g_fM2ControlOutOld+fP+g_fM2ControlIntegral;
    if(g_fM2ControlOutNew>=120)	{g_fM2ControlOutNew=120;}
	if(g_fM2ControlOutNew<=0)	{g_fM2ControlOutNew=0;}
	TIM3->CCR2=(int)(g_fM2ControlOutNew*VoltageToDuty);
	g_fM2ControlOutOld=g_fM2ControlOutNew;
}
void Motor3SpeedContrl(void)
{
	float fDelta;
	float fP,fI;
	float fCarSpeed;
	fCarSpeed=g_fM3Speed;
	fCarSpeed*=CAR_SPEED_CONSTANT;
	fDelta=g_fSpeedGive-fCarSpeed;
	fP=fDelta*M3_CONTR0L_P;
	fI=fDelta*M3_CONTR0L_I;
	g_fM3ControlIntegral+=fI;
	
	g_fM3ControlOutNew=g_fM3ControlOutOld+fP+g_fM3ControlIntegral;
    if(g_fM3ControlOutNew>=120)	{g_fM3ControlOutNew=120;}
    if(g_fM3ControlOutNew<=0)	{g_fM3ControlOutNew=0;}	
	TIM3->CCR3=(int)(g_fM3ControlOutNew*VoltageToDuty);
	g_fM3ControlOutOld=g_fM3ControlOutNew;
}
