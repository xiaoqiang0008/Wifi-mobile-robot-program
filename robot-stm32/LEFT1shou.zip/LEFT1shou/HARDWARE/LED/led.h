#ifndef __LED_H
#define __LED_H	 
#include "sys.h"

#define LED PAout(2)	//PA2

#define Motor1_BG2 PCout(2)	//PC2
#define Motor1_BG4 PCout(3)	//PC3

#define Motor2_BG2 PAout(5)	//PA5
#define Motor2_BG4 PCout(4)	//PC4

#define Motor3_BG2 PBout(2)	//PB2
#define Motor3_BG4 PBout(1)	//PB1

void LED_Init(u8 s);    //LED��ʼ��

		 				    
#endif
