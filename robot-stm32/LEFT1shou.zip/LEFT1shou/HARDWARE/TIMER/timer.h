#ifndef __TIMER_H
#define __TIMER_H
#include "sys.h"
#include "include.h" 
//extern u16 sum; 
extern u8  counter,flag;
extern int speed[3];

void TIM6_Int_Init(u16 arr,u16 psc); 
void TIM7_Int_Init(u16 arr,u16 psc);
 
#endif
