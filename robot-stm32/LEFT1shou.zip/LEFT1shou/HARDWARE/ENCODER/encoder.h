#ifndef __ENCODER_H
#define __ENCODER_H
#include "sys.h"
 
void TIM5_ENCODER_Init(void); 
void TIM8_ENCODER_Init(void); 
void TIM1_ENCODER_Init(void);
 
#endif
