//////////////////////////////////////////////////////////////////////////////////	 

//������C�ļ�
//ʵ�������������С�Ƕȵ����Ƕ����趨�ٶ�������ת


////////////////////////////////////////////////////////////////////////////////// 	 
#include "stm32f10x.h"
#include "pca9685.h" 
#include "string.h"
#include "delay.h"
//#include "LED.h"
#include "timer.h"
#include "usart.h"
#include "pca9685.h" 
#include "myiic.h"
#include "wwdg.h"
#include "stm32f10x_wwdg.h"
//#include "public.h"
#include "ds18b20.h"
//#include "hcsr04.h"
#include "printf.h"
#include "DHT11.h"
#include "mq.h"
#include "pca9685.h" 
#include "LED.h"
#include "timer.h"
#include "usart.h"
#include "myiic.h"
#include "wwdg.h"
#include "stm32f10x_wwdg.h"
u32 MQ4_ad1=0;
u32 MQ9_ad2=0;
double tp_temp;
u8 dht11_tp_temp;
u8 dht11_hd_temp;
int main(void)
{
//	u32 hcsr04_temp;
	u8 buff[6];
	u8 MQ4_i;
	u8 MQ9_i;
	Servo_now servonow;
	Servo_cfg servocfg;
	u8 servo[10];
	buff[0]=0xff;
	buff[5]=0xff;     
	delay_init(72);          //72M 
	
	printf_init();
  ds18b20_IO_Init();
	/**************************************/
	
//	printf_init();
//	hcsr04_Trig_INIT();
//	hcsr04_Echo_INIT();
//	hcsr04_catch_INIT();
//	hcsr04_Trig_L;
    /*******************************************/
//	printf_init();
//	ADX345_Init();
//	ADX345_Adjust();
	/*******************************************/
	DHT11_Init();
	/********************************************/
	adc_Init();
	/*********************************************/
	
	
	LED_Int(GPIOA,GPIO_Pin_8,RCC_APB2Periph_GPIOA);//led
	LED_Int(GPIOD,GPIO_Pin_2,RCC_APB2Periph_GPIOD);
	NVIC_Configuration();    //����NVIC�жϷ���2:2λ��ռ���ȼ���2λ��Ӧ���ȼ�
	LED_Init();		  	       //��ʼ����LED���ӵ�Ӳ���ӿ�
	TIM7_Int_Init(9,7199);//10Khz�ļ���Ƶ�ʣ�5ms 
	TIM6_Int_Init(4999,7199);//10Khz�ļ���Ƶ�ʣ�������5000Ϊ500ms  
	TIM2_PWM_Init(3600,67,2450);//     Tclk/((arr+1)*(psc+1))        200Hz    �����ʼ����2450�������
	uart3_init(9600);
	uart2_init(9600);
	uart4_init(115200);	     //����4��ʼ��Ϊ115200
	IIC_Init(); 
	//����pca9685�Ĺ���Ƶ��
	//������SLEEPģʽ�²������
	//���Ա����ڳ����ʼ��ʱ���
 	pca9685_WriteOneByte(0x00,0x30);
	pca9685_WriteOneByte(0xfe,0x7c);
	
	init_pca9685();			//IIC��ʼ�� 
//	delay_ms(1000);
Servo_control(SERVO_1,250);
Servo_control(SERVO_2,250);
Servo_control(SERVO_3,250);
Servo_control(SERVO_4,600);
Servo_control(SERVO_5,250);
Servo_control(SERVO_6,800);
	
servonow.Servonow_1=250;
servonow.Servonow_2=600;
servonow.Servonow_3=250;
servonow.Servonow_4=250;
servonow.Servonow_5=250;
servonow.Servonow_6=800;
servocfg.Servospeed_1=servo_dutyshift(70);
servocfg.Servotime_1=30;
servocfg.Servospeed_2=servo_dutyshift(0);
servocfg.Servotime_2=30;
servocfg.Servospeed_3=servo_dutyshift(0);
servocfg.Servotime_3=30;
servocfg.Servospeed_4=servo_dutyshift1(0);//5�Ŷ���Ƕȷ�ΧΪ0~144��    ��  450~1250
servocfg.Servotime_4=30;
servocfg.Servospeed_5=servo_dutyshift(0);
servocfg.Servotime_5=30;
servocfg.Servospeed_6=servo_dutyshift3(60);
servocfg.Servotime_6=30;
	while(1)
	{
	    tp_temp=readtemp();
        printf("��ǰ�¶�Ϊ:%0.4lf ��\r\n",tp_temp);

			DHT11_Read_Data(&dht11_tp_temp,&dht11_hd_temp);	//��ȡ��ʪ��ֵ					    
			printf("��ǰ�¶�Ϊ:%d ��\r\n",dht11_tp_temp);//��ʾ�¶�	   		   
			printf("��ǰʪ��Ϊ:%d RH\r\n",dht11_hd_temp);//��ʾʪ��
	/***************************************************/
			for(MQ4_i=0;MQ4_i<50;MQ4_i++)
			{
				ADC_SoftwareStartConvCmd(ADC1, ENABLE);
				while(!ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC));
				MQ4_ad1=MQ4_ad1+ADC_GetConversionValue(ADC1);
			}
			for(MQ9_i=0;MQ9_i<50;MQ9_i++)
			{
			ADC_SoftwareStartConvCmd(ADC2, ENABLE);
			while(!ADC_GetFlagStatus(ADC2, ADC_FLAG_EOC));
			MQ9_ad2=MQ9_ad2+ADC_GetConversionValue(ADC2);
			}
			MQ4_ad1=MQ4_ad1/50;
			MQ9_ad2=MQ9_ad2/50;
        printf("ad1=%fV\r\n",MQ4_ad1*3.3/4096);
		printf("ad2=%fV\r\n",MQ9_ad2*3.3/4096);

		if(set==1&&wifi_buf[1]==0xaa)
		{
			servocfg.Servospeed_1=servo_dutyshift(wifi_buf[2]);
			servocfg.Servotime_1=wifi_buf[3];
			servocfg.Servospeed_2=servo_dutyshift(wifi_buf[4]);
			servocfg.Servotime_2=wifi_buf[5];
			servocfg.Servospeed_3=servo_dutyshift(wifi_buf[6]);
			servocfg.Servotime_3=wifi_buf[7];
			servocfg.Servospeed_4=servo_dutyshift1(wifi_buf[8]);//5�Ŷ���Ƕȷ�ΧΪ0~144��    ��  450~1250
			servocfg.Servotime_4=wifi_buf[9];
			servocfg.Servospeed_5=servo_dutyshift(wifi_buf[10]);
			servocfg.Servotime_5=wifi_buf[11];
			Actu_ChangeDuty(servo_dutyshift2(wifi_buf[12]));//ץ��
			servocfg.Servospeed_6=servo_dutyshift3(wifi_buf[12]);//��̨
			servocfg.Servotime_6=wifi_buf[13];
			set=0;
		}
		Speed_control1(&servocfg , &servonow);
		servo[0] = 0xff;
		servo[1] = 0xa3;
		servo[2] = (servonow.Servonow_1-250)*9/50;
		servo[3] = (servonow.Servonow_2-250)*9/50;
		servo[4] = (servonow.Servonow_3-250)*9/50;
		servo[5] = (servonow.Servonow_4-600)*135/750;
		servo[6] = (servonow.Servonow_5-250)*9/50;
		servo[7] = (servonow.Servonow_6-250)*9/50;
		servo[8] = servo[1]+servo[2]+servo[3]+servo[4]+servo[5]+servo[6]+servo[7];
		if(servo[8] == 0xff) servo[0] = 0xfe;
		servo[9] = 0xff;
		USART2_Send_bytes(servo,10);
		
		buff[1]=0xa1;
		buff[2]=(u8)(MQ4_ad1*256/4096);//
		buff[3]=(u8)(MQ9_ad2*256/4096);//
		buff[4]=buff[1]+buff[2]+buff[3];
		if(buff[4] == 0xff) buff[4] = 0xfe;
		USART2_Send_bytes(buff,6);
		buff[1]=0xa2;
		buff[2]=(u8)(tp_temp);
		buff[3]=dht11_hd_temp;
		buff[4]=buff[1]+buff[2]+buff[3];
		if(buff[4] == 0xff) buff[4] = 0xfe;
		USART2_Send_bytes(buff,6);
	//	Servo_control(SERVO_6,1050);
	}
}
