#ifndef   _ds18b20_H
#define   _ds18b20_H
#include  "stm32f10x.h"
#include "delay.h"

#define dq GPIO_Pin_11   //PG11
#define GPIO_ds18b20  GPIOG
#define ds18b20_dq_H  GPIO_SetBits(GPIO_ds18b20,dq)
#define ds18b20_dq_L  GPIO_ResetBits(GPIO_ds18b20,dq)

void ds18b20_IO_Init(void);
void DQ_In_Init(void);
void DQ_Out_Init(void);
void ds18b20_PC_Init(void);
void ds18b20wr(u8 dat);
u8 ds18b20rd(void);
double readtemp(void);


#endif
