#ifndef _printf_H
#define _printf_H
#include "stm32f10x.h"
#include "stdio.h"
int fputc(int ch,FILE *p);
void printf_init(void);



#endif
