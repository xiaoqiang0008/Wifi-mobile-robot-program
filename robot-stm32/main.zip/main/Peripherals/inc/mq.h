#ifndef _adc_H
#define _adc_H
#include "stm32f10x.h"
#include "printf.h"
#include "delay.h"
#include "stm32f10x_adc.h"


void adc_Init(void);


#endif
