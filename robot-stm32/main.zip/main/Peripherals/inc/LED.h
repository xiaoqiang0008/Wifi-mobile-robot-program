
 //////////////////////////////////////////////////////////////////////////////////	 

//�������˿�����ͷ�ļ�


////////////////////////////////////////////////////////////////////////////////// 	 
 
#ifndef __LED_H
#define __LED_H
#include "stm32f10x.h"
#include "sys.h"
 void LED_Int(GPIO_TypeDef* GPIOx,uint16_t GPIO_PinX,uint32_t time);
void LED_Init(void);//��ʼ��

#define L_HC_SR501_DO PBin(5)
#define R_HC_SR501_DO PBin(8)
#define U_HC_SR501_DO PBin(9)
#define D_HC_SR501_DO PCin(15)
#define MQ7_DO PBin(6)
#define MQ4_DO PBin(7)
#endif

