#ifndef _hcsr04_H
#define _hcsr04_H
#include "stm32f10x.h"
#include "printf.h"
#include "delay.h"

//void HCSR04_INIT(void);
void hcsr04_Trig_INIT(void);
void hcsr04_Echo_INIT(void);
void hcsr04_catch_INIT(void);
//void TIM5_CC_IRQHandler(void);

extern u8 TIM5CH1_CAPTURE_STA;
extern u16 TIM5CH1_CAPTURE_VAL;


#define GPIO_hcsr04 GPIOA
#define hcsr04_Trig GPIO_Pin_1
#define hcsr04_Echo GPIO_Pin_0


#define hcsr04_Trig_H GPIO_SetBits(GPIO_hcsr04,hcsr04_Trig)
#define hcsr04_Trig_L GPIO_ResetBits(GPIO_hcsr04,hcsr04_Trig)

#define hcsr04_Echo_H GPIO_SetBits(GPIO_hcsr04,hcsr04_Echo)
#define hcsr04_Echo_L GPIO_ResetBits(GPIO_hcsr04,hcsr04_Echo)

#endif


