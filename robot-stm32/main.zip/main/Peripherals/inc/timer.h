
//////////////////////////////////////////////////////////////////////////////////	 

//��ʱ����ʼ�����жϷ��������ͷ�ļ�

////////////////////////////////////////////////////////////////////////////////// 

#ifndef __TIMER_H
#define __TIMER_H
#include "sys.h"
extern u32 MQ4_ad1;
extern u32 MQ9_ad2;
extern double tp_temp;
//extern u8 dht11_tp_temp;
extern u8 dht11_hd_temp;

void TIM6_Int_Init(u16 arr,u16 psc); 
void TIM7_Int_Init(u16 arr,u16 psc); 
void TIM2_PWM_Init(u16 arr,u16 psc,u16 duty);
void Actu_ChangeDuty(u16 duty);
#endif
