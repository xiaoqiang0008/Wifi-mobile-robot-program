//////////////////////////////////////////////////////////////////////////////////	 

//���������PCA9685������������C�ļ�


////////////////////////////////////////////////////////////////////////////////// 	 
#include "pca9685.h"
#include "pca9685_reg.h"    /* Light Driver Chip */
#include "myiic.h"
#include "delay.h"
#define MAX_OUTPUT_INDEX	15
#define MAX_OUTPUT_VALUE	0xFFF

#define SPEED_CTR      10
#define INCREMENTAL    30     //����

Servo_flag servo_flag1,servo_flag2,servo_flag3,servo_flag4,servo_flag5,servo_flag6,servo_flag7,servo_flag8;


/***************************************************
�Ƕ�ת��
***************************************************/
u32 servo_dutyshift(u8 duty)
{
	u32 Duty;
	Duty=(50/9)*duty+250;
	return Duty;
}

u32 servo_dutyshift1(u8 duty)
{
	u32 Duty;
	Duty=(750/135)*duty+600;
	return Duty;
}

//ץ��
u32 servo_dutyshift2(u8 duty)
{
	u32 Duty;
	Duty=(250/9)*duty+2300;
	return Duty;
}
//��̨
u32 servo_dutyshift3(u8 duty)
{
	u32 Duty;
	Duty=(50/12)*duty+550;
	return Duty;
}


/***************************************************
pca9685��ʼ������
***************************************************/
    
void init_pca9685(void)
{
	u8 buf[2];
	IIC_Init();  
	buf[0] =0x20;
	buf[1] = PCA9685_OUTDRV;
	pca9685_WriteOneByte(0x00,buf[0]);
	pca9685_WriteOneByte(0x01,buf[1]);
}

/****************************************************
������Ƴ���

��ڲ����� id    0~6    ���id�� 0~6
					 percent   0~10000   ����ռ�ձ�0~100%
****************************************************/

void Servo_control(char id ,int percent )
{
	unsigned int on, off,addr;
	u8 values[4];

    if (percent == 0) 
		{
			values[PCA9685_LED_ON_H] = 0; 
			values[PCA9685_LED_OFF_H] = PCA9685_LED_OFF;
    }
    else if (percent == 10000) 
		{
			values[PCA9685_LED_ON_H] = PCA9685_LED_ON;
			values[PCA9685_LED_OFF_H] = 0;
    }
    on = 0;
    off = (4096 * percent) / 10000;
    values[PCA9685_LED_ON_L] = on & 0xff;//0
    values[PCA9685_LED_ON_H] = (on >> 8) & 0xf;//1
    values[PCA9685_LED_OFF_L] = off & 0xff;//2
    values[PCA9685_LED_OFF_H] = (off >> 8) & 0xf;//3
		
   
    if (id==(char)PCA9685_ALL_LEDS) 
		{
        addr=PCA9685_ALL_LED_ON_L;
    } 
		else 
		{
        addr = PCA9685_BASE2(id);
    }
		
		pca9685_Write(addr,values,4);
}

/****************************************************

��pca9685ָ����ַд��һ������

��ڲ�����
				WriteAddr  :д�����ݵ�Ŀ�ĵ�ַ    
				DataToWrite:Ҫд�������

****************************************************/
char dutynew_flag;
void Speed_control1(Servo_cfg* servocfg , Servo_now* servo_now)
{
	if(dutynew_flag==0)
	{
		dutynew_flag=1;
		servo_flag1.dutynew=250;
		servo_flag2.dutynew=250;
		servo_flag3.dutynew=250;
		servo_flag4.dutynew=550;
		servo_flag5.dutynew=250;
		servo_flag6.dutynew=250;
		servo_flag7.dutynew=250;
		servo_flag8.dutynew=250;
		
		servo_flag1.dutynow=250;
		servo_flag2.dutynow=250;
		servo_flag3.dutynow=250;
		servo_flag4.dutynow=550;
		servo_flag5.dutynow=250;
		servo_flag6.dutynow=800;
		servo_flag7.dutynow=250;
		servo_flag8.dutynow=250;
	}
	//���1�ſ��Ƴ���
	if(servocfg->Servospeed_1!=servo_flag1.dutynew||servocfg->Servotime_1!=servo_flag1.timenew)
		{
			servo_flag1.dutynew = servocfg->Servospeed_1;
			servo_flag1.timenew = servocfg->Servotime_1;
			
			servo_flag1.dutylast=servo_flag1.dutynow;
			servo_flag1.count=0;
			
			if( servocfg->Servospeed_1 > servo_flag1.dutylast )
			{
						servo_flag1.dutyx = servocfg->Servospeed_1-servo_flag1.dutylast;
			}
			else
			{
						servo_flag1.dutyx=servo_flag1.dutylast-servocfg->Servospeed_1;
			}

		}
		if(timer_up1==1)
		{
			timer_up1=0;
			servo_flag1.count++;
			if(servo_flag1.dutynew>servo_flag1.dutylast)
			{
				//servo_flag1.duty1=(servo_flag1.dutyx*SPEED_CTR)/servo_flag1.timenew;
				servo_flag1.dutynow=servo_flag1.dutylast+servo_flag1.timenew*servo_flag1.count;
				Servo_control(SERVO_1,servo_flag1.dutynow);
				
				if(servo_flag1.dutynow>servo_flag1.dutynew||servo_flag1.dutynow==servo_flag1.dutynew)
				{
					Servo_control(SERVO_1,servo_flag1.dutynew);
					servo_flag1.dutylast=servo_flag1.dutynew;
					servo_flag1.dutynow=servo_flag1.dutynew;
					servo_flag1.count=0;
					timer_up1=0;
				}
			}
			else if(servo_flag1.dutynew<servo_flag1.dutylast)
			{
				
				//servo_flag1.duty1=(servo_flag1.dutyx*SPEED_CTR)/servo_flag1.timenew;
				servo_flag1.dutynow=servo_flag1.dutylast-servo_flag1.timenew*servo_flag1.count;
				Servo_control(SERVO_1,servo_flag1.dutynow);
				
				if(servo_flag1.dutynow<servo_flag1.dutynew||servo_flag1.dutynow==servo_flag1.dutynew)
				{
					Servo_control(SERVO_1,servo_flag1.dutynew);
					servo_flag1.dutylast=servo_flag1.dutynew;
					servo_flag1.dutynow=servo_flag1.dutynew;
					servo_flag1.count=0;
					timer_up1=0;
				}
			}
			else
			{
				
			}
			servo_now->Servonow_1=servo_flag1.dutynow;//������ĵ�ǰֵ���ݳ�ȥ��
		}
		
		//���2�ſ��Ƴ���

		if(servocfg->Servospeed_2!=servo_flag2.dutynew||servocfg->Servotime_2!=servo_flag2.timenew)
		{
			servo_flag2.dutynew = servocfg->Servospeed_2;
			servo_flag2.timenew = servocfg->Servotime_2;
			
			servo_flag2.dutylast=servo_flag2.dutynow;
			servo_flag2.count=0;
			
			if( servocfg->Servospeed_2 > servo_flag2.dutylast )
			{
						servo_flag2.dutyx = servocfg->Servospeed_2-servo_flag2.dutylast;
			}
			else
			{
						servo_flag2.dutyx=servo_flag2.dutylast-servocfg->Servospeed_2;
			}

		}
		if(timer_up2==1)
		{
			timer_up2=0;
			servo_flag2.count++;
			if(servo_flag2.dutynew>servo_flag2.dutylast)
			{
				//servo_flag2.duty1=(servo_flag2.dutyx*SPEED_CTR)/servo_flag2.timenew;
				servo_flag2.dutynow=servo_flag2.timenew*servo_flag2.count+servo_flag2.dutylast;
				Servo_control(SERVO_2,servo_flag2.dutynow);
				
				if(servo_flag2.dutynow>servo_flag2.dutynew||servo_flag2.dutynow==servo_flag2.dutynew)
				{
					Servo_control(SERVO_2,servo_flag2.dutynew);
					servo_flag2.dutylast=servo_flag2.dutynew;
					servo_flag2.dutynow=servo_flag2.dutynew;
					servo_flag2.count=0;
					timer_up2=0;
				}
			}
			else if(servo_flag2.dutynew<servo_flag2.dutylast)
			{
				
				//servo_flag2.duty1=(servo_flag2.dutyx*SPEED_CTR)/servo_flag2.timenew;
				servo_flag2.dutynow=servo_flag2.dutylast-servo_flag2.timenew*servo_flag2.count;
				Servo_control(SERVO_2,servo_flag2.dutynow);
				
				if(servo_flag2.dutynow<servo_flag2.dutynew||servo_flag2.dutynow==servo_flag2.dutynew)
				{
					Servo_control(SERVO_2,servo_flag2.dutynew);
					servo_flag2.dutylast=servo_flag2.dutynew;
					servo_flag2.dutynow=servo_flag2.dutynew;
					servo_flag2.count=0;
					timer_up2=0;
				}
			}
			else
			{

			}
			servo_now->Servonow_2=servo_flag2.dutynow;//������ĵ�ǰֵ���ݳ�ȥ��
		}
		
		
		//���3�ſ��Ƴ���

		if(servocfg->Servospeed_3!=servo_flag3.dutynew||servocfg->Servotime_3!=servo_flag3.timenew)
		{
			servo_flag3.dutynew = servocfg->Servospeed_3;
			servo_flag3.timenew = servocfg->Servotime_3;
			
			servo_flag3.dutylast=servo_flag3.dutynow;
			servo_flag3.count=0;
			
			if( servocfg->Servospeed_3 > servo_flag3.dutylast )
			{
						servo_flag3.dutyx = servocfg->Servospeed_3-servo_flag3.dutylast;
			}
			else
			{
						servo_flag3.dutyx=servo_flag3.dutylast-servocfg->Servospeed_3;
			}

		}
		if(timer_up3==1)
		{
			timer_up3=0;
			servo_flag3.count++;
			if(servo_flag3.dutynew>servo_flag3.dutylast)
			{
				//servo_flag3.duty1=(servo_flag3.dutyx*SPEED_CTR)/servo_flag3.timenew;
				servo_flag3.dutynow=servo_flag3.timenew*servo_flag3.count+servo_flag3.dutylast;
				Servo_control(SERVO_3,servo_flag3.dutynow);
				if(servo_flag3.dutynow>servo_flag3.dutynew||servo_flag3.dutynow==servo_flag3.dutynew)
				{
					Servo_control(SERVO_3,servo_flag3.dutynew);
					servo_flag3.dutylast=servo_flag3.dutynew;
					servo_flag3.dutynow=servo_flag3.dutynew;
					servo_flag3.count=0;
					timer_up3=0;
				}
			}
			else if(servo_flag3.dutynew<servo_flag3.dutylast)
			{
				
			//	servo_flag3.duty1=(servo_flag3.dutyx*SPEED_CTR)/servo_flag3.timenew;
				servo_flag3.dutynow=servo_flag3.dutylast-servo_flag3.timenew*servo_flag3.count;
				Servo_control(SERVO_3,servo_flag3.dutynow);
				
				if(servo_flag3.dutynow<servo_flag3.dutynew||servo_flag3.dutynow==servo_flag3.dutynew)
				{
					Servo_control(SERVO_3,servo_flag3.dutynew);
					servo_flag3.dutylast=servo_flag3.dutynew;
					servo_flag3.dutynow=servo_flag3.dutynew;
					servo_flag3.count=0;
					timer_up3=0;
				}
			}
			else
			{

			}
			servo_now->Servonow_3=servo_flag3.dutynow;//������ĵ�ǰֵ���ݳ�ȥ��
		}
		
		//���4�ſ��Ƴ���

		if(servocfg->Servospeed_4!=servo_flag4.dutynew||servocfg->Servotime_4!=servo_flag4.timenew)
		{
			servo_flag4.dutynew = servocfg->Servospeed_4;
			servo_flag4.timenew = servocfg->Servotime_4;
			
			servo_flag4.dutylast=servo_flag4.dutynow;
			servo_flag4.count=0;
			
			if( servocfg->Servospeed_4 > servo_flag4.dutylast )
			{
						servo_flag4.dutyx = servocfg->Servospeed_4-servo_flag4.dutylast;
			}
			else
			{
						servo_flag4.dutyx=servo_flag4.dutylast-servocfg->Servospeed_4;
			}

		}
		if(timer_up4==1)
		{
			timer_up4=0;
			servo_flag4.count++;
			if(servo_flag4.dutynew>servo_flag4.dutylast)
			{
				//servo_flag4.duty1=(servo_flag4.dutyx*SPEED_CTR)/servo_flag4.timenew;
				servo_flag4.dutynow=servo_flag4.timenew*servo_flag4.count+servo_flag4.dutylast;
				Servo_control(SERVO_4,servo_flag4.dutynow);
				
				if(servo_flag4.dutynow>servo_flag4.dutynew||servo_flag4.dutynow==servo_flag4.dutynew)
				{
					Servo_control(SERVO_4,servo_flag4.dutynew);
					servo_flag4.dutylast=servo_flag4.dutynew;
					servo_flag4.dutynow=servo_flag4.dutynew;
					servo_flag4.count=0;
					timer_up4=0;
				}
			}
			else if(servo_flag4.dutynew<servo_flag4.dutylast)
			{
				
				//servo_flag4.duty1=(servo_flag4.dutyx*SPEED_CTR)/servo_flag4.timenew;
				servo_flag4.dutynow=servo_flag4.dutylast-servo_flag4.timenew*servo_flag4.count;
				Servo_control(SERVO_4,servo_flag4.dutynow);
				
				if(servo_flag4.dutynow<servo_flag4.dutynew||servo_flag4.dutynow==servo_flag4.dutynew)
				{
					Servo_control(SERVO_4,servo_flag4.dutynew);
					servo_flag4.dutylast=servo_flag4.dutynew;
					servo_flag4.dutynow=servo_flag4.dutynew;
					servo_flag4.count=0;
					timer_up4=0;
				}
			}
			else
			{

			}
			servo_now->Servonow_4=servo_flag4.dutynow;//������ĵ�ǰֵ���ݳ�ȥ��
		}
		
		
		//���5�ſ��Ƴ���

		if(servocfg->Servospeed_5!=servo_flag5.dutynew||servocfg->Servotime_5!=servo_flag5.timenew)
		{
			servo_flag5.dutynew = servocfg->Servospeed_5;
			servo_flag5.timenew = servocfg->Servotime_5;
			
			servo_flag5.dutylast=servo_flag5.dutynow;
			servo_flag5.count=0;
			
			if( servocfg->Servospeed_5 > servo_flag5.dutylast )
			{
						servo_flag5.dutyx = servocfg->Servospeed_5-servo_flag5.dutylast;
			}
			else
			{
						servo_flag5.dutyx=servo_flag5.dutylast-servocfg->Servospeed_5;
			}

		}
		if(timer_up5==1)
		{
			timer_up5=0;
			servo_flag5.count++;
			if(servo_flag5.dutynew>servo_flag5.dutylast)
			{
				//servo_flag5.duty1=(servo_flag5.dutyx*SPEED_CTR)/servo_flag5.timenew;
				servo_flag5.dutynow=servo_flag5.timenew*servo_flag5.count+servo_flag5.dutylast;
				Servo_control(SERVO_5,servo_flag5.dutynow);
				
				if(servo_flag5.dutynow>servo_flag5.dutynew||servo_flag5.dutynow==servo_flag5.dutynew)
				{
					Servo_control(SERVO_5,servo_flag5.dutynew);
					servo_flag5.dutylast=servo_flag5.dutynew;
					servo_flag5.dutynow=servo_flag5.dutynew;
					servo_flag5.count=0;
					timer_up5=0;
				}
			}
			else if(servo_flag5.dutynew<servo_flag5.dutylast)
			{
				
				//servo_flag5.duty1=(servo_flag5.dutyx*SPEED_CTR)/servo_flag5.timenew;
				servo_flag5.dutynow=servo_flag5.dutylast-servo_flag5.timenew*servo_flag5.count;
				Servo_control(SERVO_5,servo_flag5.dutynow);
				
				if(servo_flag5.dutynow<servo_flag5.dutynew||servo_flag5.dutynow==servo_flag5.dutynew)
				{
					Servo_control(SERVO_5,servo_flag5.dutynew);
					servo_flag5.dutylast=servo_flag5.dutynew;
					servo_flag5.dutynow=servo_flag5.dutynew;
					servo_flag5.count=0;
					timer_up5=0;
				}
			}
			else
			{

			}
			servo_now->Servonow_5=servo_flag5.dutynow;//������ĵ�ǰֵ���ݳ�ȥ��
		}
		
		//���6�ſ��Ƴ���

		if(servocfg->Servospeed_6!=servo_flag6.dutynew||servocfg->Servotime_6!=servo_flag6.timenew)
		{
			servo_flag6.dutynew = servocfg->Servospeed_6;
			servo_flag6.timenew = servocfg->Servotime_6;
			
			servo_flag6.dutylast=servo_flag6.dutynow;
			servo_flag6.count=0;
			
			if( servocfg->Servospeed_6 > servo_flag6.dutylast )
			{
						servo_flag6.dutyx = servocfg->Servospeed_6-servo_flag6.dutylast;
			}
			else
			{
						servo_flag6.dutyx=servo_flag6.dutylast-servocfg->Servospeed_6;
			}

		}
		if(timer_up6==1)
		{
			timer_up6=0;
			servo_flag6.count++;
			if(servo_flag6.dutynew>servo_flag6.dutylast)
			{
				//servo_flag6.duty1=(servo_flag6.dutyx*SPEED_CTR)/servo_flag6.timenew;
				servo_flag6.dutynow=servo_flag6.timenew*servo_flag6.count+servo_flag6.dutylast;
				Servo_control(SERVO_6,servo_flag6.dutynow);
				
				if(servo_flag6.dutynow>servo_flag6.dutynew||servo_flag6.dutynow==servo_flag6.dutynew)
				{
					Servo_control(SERVO_6,servo_flag6.dutynew);
					servo_flag6.dutylast=servo_flag6.dutynew;
					servo_flag6.dutynow=servo_flag6.dutynew;
					servo_flag6.count=0;
					timer_up6=0;
				}
			}
			else if(servo_flag6.dutynew<servo_flag6.dutylast)
			{
				
			//	servo_flag6.duty1=(servo_flag6.dutyx*SPEED_CTR)/servo_flag6.timenew;
				servo_flag6.dutynow=servo_flag6.dutylast-servo_flag6.timenew*servo_flag6.count;
				Servo_control(SERVO_6,servo_flag6.dutynow);
				
				if(servo_flag6.dutynow<servo_flag6.dutynew||servo_flag6.dutynow==servo_flag6.dutynew)
				{
					Servo_control(SERVO_6,servo_flag6.dutynew);
					servo_flag6.dutylast=servo_flag6.dutynew;
					servo_flag6.dutynow=servo_flag6.dutynew;
					servo_flag6.count=0;
					timer_up6=0;
				}
			}
			else
			{

			}
			servo_now->Servonow_6=servo_flag6.dutynow;//������ĵ�ǰֵ���ݳ�ȥ��
		}
		
		//���7�ſ��Ƴ���

		if(servocfg->Servospeed_7!=servo_flag7.dutynew||servocfg->Servotime_7!=servo_flag7.timenew)
		{
			servo_flag7.dutynew = servocfg->Servospeed_7;
			servo_flag7.timenew = servocfg->Servotime_7;
			
			servo_flag7.dutylast=servo_flag7.dutynow;
			servo_flag7.count=0;
			
			if( servocfg->Servospeed_7 > servo_flag7.dutylast )
			{
						servo_flag7.dutyx = servocfg->Servospeed_7-servo_flag7.dutylast;
			}
			else
			{
						servo_flag7.dutyx=servo_flag7.dutylast-servocfg->Servospeed_7;
			}

		}
		if(timer_up7==1)
		{
			timer_up7=0;
			servo_flag7.count++;
			if(servo_flag7.dutynew>servo_flag7.dutylast)
			{
				//servo_flag7.duty1=(servo_flag7.dutyx*SPEED_CTR)/servo_flag7.timenew;
				servo_flag7.dutynow=servo_flag7.timenew*servo_flag7.count+servo_flag7.dutylast;
				Servo_control(SERVO_7,servo_flag7.dutynow);
				
				if(servo_flag7.dutynow>servo_flag7.dutynew||servo_flag7.dutynow==servo_flag7.dutynew)
				{
					Servo_control(SERVO_7,servo_flag7.dutynew);
					servo_flag7.dutylast=servo_flag7.dutynew;
					servo_flag7.dutynow=servo_flag7.dutynew;
					servo_flag7.count=0;
					timer_up7=0;
				}
			}
			else if(servo_flag7.dutynew<servo_flag7.dutylast)
			{
				
			//	servo_flag7.duty1=(servo_flag7.dutyx*SPEED_CTR)/servo_flag7.timenew;
				servo_flag7.dutynow=servo_flag7.dutylast-servo_flag7.timenew*servo_flag7.count;
				Servo_control(SERVO_7,servo_flag7.dutynow);
				
				if(servo_flag7.dutynow<servo_flag7.dutynew||servo_flag7.dutynow==servo_flag7.dutynew)
				{
					Servo_control(SERVO_7,servo_flag7.dutynew);
					servo_flag7.dutylast=servo_flag7.dutynew;
					servo_flag7.dutynow=servo_flag7.dutynew;
					servo_flag7.count=0;
					timer_up7=0;
				}
			}
			else
			{

			}
			servo_now->Servonow_7=servo_flag7.dutynow;//������ĵ�ǰֵ���ݳ�ȥ��
		}
		
		//���8�ſ��Ƴ���

		if(servocfg->Servospeed_8!=servo_flag8.dutynew||servocfg->Servotime_8!=servo_flag8.timenew)
		{
			servo_flag8.dutynew = servocfg->Servospeed_8;
			servo_flag8.timenew = servocfg->Servotime_8;
			
			servo_flag8.dutylast=servo_flag8.dutynow;
			servo_flag8.count=0;
			
			if( servocfg->Servospeed_8 > servo_flag8.dutylast )
			{
						servo_flag8.dutyx = servocfg->Servospeed_8-servo_flag8.dutylast;
			}
			else
			{
						servo_flag8.dutyx=servo_flag8.dutylast-servocfg->Servospeed_8;
			}

		}
		if(timer_up8==1)
		{
			timer_up8=0;
			servo_flag8.count++;
			if(servo_flag8.dutynew>servo_flag8.dutylast)
			{
				//servo_flag8.duty1=(servo_flag8.dutyx*SPEED_CTR)/servo_flag8.timenew;
				servo_flag8.dutynow=servo_flag8.timenew*servo_flag8.count+servo_flag8.dutylast;
				Servo_control(SERVO_8,servo_flag8.dutynow);
				
				if(servo_flag8.dutynow>servo_flag8.dutynew||servo_flag8.dutynow==servo_flag8.dutynew)
				{
					Servo_control(SERVO_8,servo_flag8.dutynew);
					servo_flag8.dutylast=servo_flag8.dutynew;
					servo_flag8.dutynow=servo_flag8.dutynew;
					servo_flag8.count=0;
					timer_up8=0;
				}
			}
			else if(servo_flag8.dutynew<servo_flag8.dutylast)
			{
				
			//	servo_flag8.duty1=(servo_flag8.dutyx*SPEED_CTR)/servo_flag8.timenew;
				servo_flag8.dutynow=servo_flag8.dutylast-servo_flag8.timenew*servo_flag8.count;
				Servo_control(SERVO_8,servo_flag8.dutynow);
				
				if(servo_flag8.dutynow<servo_flag8.dutynew||servo_flag8.dutynow==servo_flag8.dutynew)
				{
					Servo_control(SERVO_8,servo_flag8.dutynew);
					servo_flag8.dutylast=servo_flag8.dutynew;
					servo_flag8.dutynow=servo_flag8.dutynew;
					servo_flag8.count=0;
					timer_up8=0;
				}
			}
			else
			{

			}
			servo_now->Servonow_8=servo_flag8.dutynow;//������ĵ�ǰֵ���ݳ�ȥ��
		}
}

/****************************************************
����ٶȿ��Ƴ���

��ڲ��� ��servocfg   ռ�ձ�   �ٶ��趨

					//����趨ֵ   ��  Ŀ��ֵ    ռ�ձ�   �ٶ��趨
					typedef struct
					{
						u32 Servospeed_1;//���1���趨ռ�ձ�
						u32 Servotime_1;//���1���趨����ʱ��
						u32 Servospeed_2;
						u32 Servotime_2;
						u32 Servospeed_3;
						u32 Servotime_3;
						u32 Servospeed_4;
						u32 Servotime_4;
						u32 Servospeed_5;
						u32 Servotime_5;
						u32 Servospeed_6;
						u32 Servotime_6;
					}Servo_cfg;
���ڲ��� ��servo_now    �����ǰռ�ձ�
					typedef struct
					{
						u32 Servonow_1;
						u32 Servonow_2;
						u32 Servonow_3;
						u32 Servonow_4;
						u32 Servonow_5;
						u32 Servonow_6;
					}Servo_now;
****************************************************/

void Speed_control2(Servo_cfg* servocfg , Servo_now* servo_now)
{
	if(dutynew_flag==0)
	{
		dutynew_flag=1;
		servo_flag1.dutynew=250;
		servo_flag2.dutynew=250;
		servo_flag3.dutynew=250;
		servo_flag4.dutynew=550;
		servo_flag5.dutynew=250;
		servo_flag6.dutynew=250;
		servo_flag1.dutynow=250;
		servo_flag2.dutynow=250;
		servo_flag3.dutynow=250;
		servo_flag4.dutynow=550;
		servo_flag5.dutynow=250;
		servo_flag6.dutynow=800;
	}
//���1�ſ��Ƴ���
		if(servocfg->Servospeed_1!=servo_flag1.dutynew||servocfg->Servotime_1!=servo_flag1.timenew)
		{
			servo_flag1.dutynew = servocfg->Servospeed_1;
			servo_flag1.timenew = servocfg->Servotime_1;
			
			servo_flag1.dutylast=servo_flag1.dutynow;
			servo_flag1.count=0;
			
			if( servocfg->Servospeed_1 > servo_flag1.dutylast )
			{
						servo_flag1.dutyx = servocfg->Servospeed_1-servo_flag1.dutylast;
			}
			else
			{
						servo_flag1.dutyx=servo_flag1.dutylast-servocfg->Servospeed_1;
			}

		}
		if(timer_up1==1)
		{
			timer_up1=0;
			servo_flag1.count++;
			if(servo_flag1.dutynew>servo_flag1.dutylast)
			{
				servo_flag1.duty1=(servo_flag1.dutyx*SPEED_CTR)/servo_flag1.timenew;
				servo_flag1.dutynow=servo_flag1.duty1*servo_flag1.count+servo_flag1.dutylast;
				Servo_control(SERVO_1,servo_flag1.dutynow);
				
				if(servo_flag1.dutynow>servo_flag1.dutynew||servo_flag1.dutynow==servo_flag1.dutynew)
				{
					Servo_control(SERVO_1,servo_flag1.dutynew);
					servo_flag1.dutylast=servo_flag1.dutynew;
					servo_flag1.dutynow=servo_flag1.dutynew;
					servo_flag1.count=0;
					timer_up1=0;
				}
			}
			else if(servo_flag1.dutynew<servo_flag1.dutylast)
			{
				
				servo_flag1.duty1=(servo_flag1.dutyx*SPEED_CTR)/servo_flag1.timenew;
				servo_flag1.dutynow=servo_flag1.dutylast-servo_flag1.duty1*servo_flag1.count;
				Servo_control(SERVO_1,servo_flag1.dutynow);
				
				if(servo_flag1.dutynow<servo_flag1.dutynew||servo_flag1.dutynow==servo_flag1.dutynew)
				{
					Servo_control(SERVO_1,servo_flag1.dutynew);
					servo_flag1.dutylast=servo_flag1.dutynew;
					servo_flag1.dutynow=servo_flag1.dutynew;
					servo_flag1.count=0;
					timer_up1=0;
				}
			}
			else
			{
				
			}
			servo_now->Servonow_1=servo_flag1.dutynow;//������ĵ�ǰֵ���ݳ�ȥ��
		}
		
		//���2�ſ��Ƴ���

		if(servocfg->Servospeed_2!=servo_flag2.dutynew||servocfg->Servotime_2!=servo_flag2.timenew)
		{
			servo_flag2.dutynew = servocfg->Servospeed_2;
			servo_flag2.timenew = servocfg->Servotime_2;
			
			servo_flag2.dutylast=servo_flag2.dutynow;
			servo_flag2.count=0;
			
			if( servocfg->Servospeed_2 > servo_flag2.dutylast )
			{
						servo_flag2.dutyx = servocfg->Servospeed_2-servo_flag2.dutylast;
			}
			else
			{
						servo_flag2.dutyx=servo_flag2.dutylast-servocfg->Servospeed_2;
			}

		}
		if(timer_up2==1)
		{
			timer_up2=0;
			servo_flag2.count++;
			if(servo_flag2.dutynew>servo_flag2.dutylast)
			{
				servo_flag2.duty1=(servo_flag2.dutyx*SPEED_CTR)/servo_flag2.timenew;
				servo_flag2.dutynow=servo_flag2.duty1*servo_flag2.count+servo_flag2.dutylast;
				Servo_control(SERVO_2,servo_flag2.dutynow);
				
				if(servo_flag2.dutynow>servo_flag2.dutynew||servo_flag2.dutynow==servo_flag2.dutynew)
				{
					Servo_control(SERVO_2,servo_flag2.dutynew);
					servo_flag2.dutylast=servo_flag2.dutynew;
					servo_flag2.dutynow=servo_flag2.dutynew;
					servo_flag2.count=0;
					timer_up2=0;
				}
			}
			else if(servo_flag2.dutynew<servo_flag2.dutylast)
			{
				
				servo_flag2.duty1=(servo_flag2.dutyx*SPEED_CTR)/servo_flag2.timenew;
				servo_flag2.dutynow=servo_flag2.dutylast-servo_flag2.duty1*servo_flag2.count;
				Servo_control(SERVO_2,servo_flag2.dutynow);
				
				if(servo_flag2.dutynow<servo_flag2.dutynew||servo_flag2.dutynow==servo_flag2.dutynew)
				{
					Servo_control(SERVO_2,servo_flag2.dutynew);
					servo_flag2.dutylast=servo_flag2.dutynew;
					servo_flag2.dutynow=servo_flag2.dutynew;
					servo_flag2.count=0;
					timer_up2=0;
				}
			}
			else
			{

			}
			servo_now->Servonow_2=servo_flag2.dutynow;//������ĵ�ǰֵ���ݳ�ȥ��
		}
		
		
		//���3�ſ��Ƴ���

		if(servocfg->Servospeed_3!=servo_flag3.dutynew||servocfg->Servotime_3!=servo_flag3.timenew)
		{
			servo_flag3.dutynew = servocfg->Servospeed_3;
			servo_flag3.timenew = servocfg->Servotime_3;
			
			servo_flag3.dutylast=servo_flag3.dutynow;
			servo_flag3.count=0;
			
			if( servocfg->Servospeed_3 > servo_flag3.dutylast )
			{
						servo_flag3.dutyx = servocfg->Servospeed_3-servo_flag3.dutylast;
			}
			else
			{
						servo_flag3.dutyx=servo_flag3.dutylast-servocfg->Servospeed_3;
			}

		}
		if(timer_up3==1)
		{
			timer_up3=0;
			servo_flag3.count++;
			if(servo_flag3.dutynew>servo_flag3.dutylast)
			{
				servo_flag3.duty1=(servo_flag3.dutyx*SPEED_CTR)/servo_flag3.timenew;
				servo_flag3.dutynow=servo_flag3.duty1*servo_flag3.count+servo_flag3.dutylast;
				Servo_control(SERVO_3,servo_flag3.dutynow);
				if(servo_flag3.dutynow>servo_flag3.dutynew||servo_flag3.dutynow==servo_flag3.dutynew)
				{
					Servo_control(SERVO_3,servo_flag3.dutynew);
					servo_flag3.dutylast=servo_flag3.dutynew;
					servo_flag3.dutynow=servo_flag3.dutynew;
					servo_flag3.count=0;
					timer_up3=0;
				}
			}
			else if(servo_flag3.dutynew<servo_flag3.dutylast)
			{
				
				servo_flag3.duty1=(servo_flag3.dutyx*SPEED_CTR)/servo_flag3.timenew;
				servo_flag3.dutynow=servo_flag3.dutylast-servo_flag3.duty1*servo_flag3.count;
				Servo_control(SERVO_3,servo_flag3.dutynow);
				
				if(servo_flag3.dutynow<servo_flag3.dutynew||servo_flag3.dutynow==servo_flag3.dutynew)
				{
					Servo_control(SERVO_3,servo_flag3.dutynew);
					servo_flag3.dutylast=servo_flag3.dutynew;
					servo_flag3.dutynow=servo_flag3.dutynew;
					servo_flag3.count=0;
					timer_up3=0;
				}
			}
			else
			{

			}
			servo_now->Servonow_3=servo_flag3.dutynow;//������ĵ�ǰֵ���ݳ�ȥ��
		}
		
		//���3�ſ��Ƴ���

		if(servocfg->Servospeed_4!=servo_flag4.dutynew||servocfg->Servotime_4!=servo_flag4.timenew)
		{
			servo_flag4.dutynew = servocfg->Servospeed_4;
			servo_flag4.timenew = servocfg->Servotime_4;
			
			servo_flag4.dutylast=servo_flag4.dutynow;
			servo_flag4.count=0;
			
			if( servocfg->Servospeed_4 > servo_flag4.dutylast )
			{
						servo_flag4.dutyx = servocfg->Servospeed_4-servo_flag4.dutylast;
			}
			else
			{
						servo_flag4.dutyx=servo_flag4.dutylast-servocfg->Servospeed_4;
			}

		}
		if(timer_up4==1)
		{
			timer_up4=0;
			servo_flag4.count++;
			if(servo_flag4.dutynew>servo_flag4.dutylast)
			{
				servo_flag4.duty1=(servo_flag4.dutyx*SPEED_CTR)/servo_flag4.timenew;
				servo_flag4.dutynow=servo_flag4.duty1*servo_flag4.count+servo_flag4.dutylast;
				Servo_control(SERVO_4,servo_flag4.dutynow);
				
				if(servo_flag4.dutynow>servo_flag4.dutynew||servo_flag4.dutynow==servo_flag4.dutynew)
				{
					Servo_control(SERVO_4,servo_flag4.dutynew);
					servo_flag4.dutylast=servo_flag4.dutynew;
					servo_flag4.dutynow=servo_flag4.dutynew;
					servo_flag4.count=0;
					timer_up4=0;
				}
			}
			else if(servo_flag4.dutynew<servo_flag4.dutylast)
			{
				
				servo_flag4.duty1=(servo_flag4.dutyx*SPEED_CTR)/servo_flag4.timenew;
				servo_flag4.dutynow=servo_flag4.dutylast-servo_flag4.duty1*servo_flag4.count;
				Servo_control(SERVO_4,servo_flag4.dutynow);
				
				if(servo_flag4.dutynow<servo_flag4.dutynew||servo_flag4.dutynow==servo_flag4.dutynew)
				{
					Servo_control(SERVO_4,servo_flag4.dutynew);
					servo_flag4.dutylast=servo_flag4.dutynew;
					servo_flag4.dutynow=servo_flag4.dutynew;
					servo_flag4.count=0;
					timer_up4=0;
				}
			}
			else
			{

			}
			servo_now->Servonow_4=servo_flag4.dutynow;//������ĵ�ǰֵ���ݳ�ȥ��
		}
		
		
		//���5�ſ��Ƴ���

		if(servocfg->Servospeed_5!=servo_flag5.dutynew||servocfg->Servotime_5!=servo_flag5.timenew)
		{
			servo_flag5.dutynew = servocfg->Servospeed_5;
			servo_flag5.timenew = servocfg->Servotime_5;
			
			servo_flag5.dutylast=servo_flag5.dutynow;
			servo_flag5.count=0;
			
			if( servocfg->Servospeed_5 > servo_flag5.dutylast )
			{
						servo_flag5.dutyx = servocfg->Servospeed_5-servo_flag5.dutylast;
			}
			else
			{
						servo_flag5.dutyx=servo_flag5.dutylast-servocfg->Servospeed_5;
			}

		}
		if(timer_up5==1)
		{
			timer_up5=0;
			servo_flag5.count++;
			if(servo_flag5.dutynew>servo_flag5.dutylast)
			{
				servo_flag5.duty1=(servo_flag5.dutyx*SPEED_CTR)/servo_flag5.timenew;
				servo_flag5.dutynow=servo_flag5.duty1*servo_flag5.count+servo_flag5.dutylast;
				Servo_control(SERVO_5,servo_flag5.dutynow);
				
				if(servo_flag5.dutynow>servo_flag5.dutynew||servo_flag5.dutynow==servo_flag5.dutynew)
				{
					Servo_control(SERVO_5,servo_flag5.dutynew);
					servo_flag5.dutylast=servo_flag5.dutynew;
					servo_flag5.dutynow=servo_flag5.dutynew;
					servo_flag5.count=0;
					timer_up5=0;
				}
			}
			else if(servo_flag5.dutynew<servo_flag5.dutylast)
			{
				
				servo_flag5.duty1=(servo_flag5.dutyx*SPEED_CTR)/servo_flag5.timenew;
				servo_flag5.dutynow=servo_flag5.dutylast-servo_flag5.duty1*servo_flag5.count;
				Servo_control(SERVO_5,servo_flag5.dutynow);
				
				if(servo_flag5.dutynow<servo_flag5.dutynew||servo_flag5.dutynow==servo_flag5.dutynew)
				{
					Servo_control(SERVO_5,servo_flag5.dutynew);
					servo_flag5.dutylast=servo_flag5.dutynew;
					servo_flag5.dutynow=servo_flag5.dutynew;
					servo_flag5.count=0;
					timer_up5=0;
				}
			}
			else
			{

			}
			servo_now->Servonow_5=servo_flag5.dutynow;//������ĵ�ǰֵ���ݳ�ȥ��
		}
		
		//���6�ſ��Ƴ���

		if(servocfg->Servospeed_6!=servo_flag6.dutynew||servocfg->Servotime_6!=servo_flag6.timenew)
		{
			servo_flag6.dutynew = servocfg->Servospeed_6;
			servo_flag6.timenew = servocfg->Servotime_6;
			
			servo_flag6.dutylast=servo_flag6.dutynow;
			servo_flag6.count=0;
			
			if( servocfg->Servospeed_6 > servo_flag6.dutylast )
			{
						servo_flag6.dutyx = servocfg->Servospeed_6-servo_flag6.dutylast;
			}
			else
			{
						servo_flag6.dutyx=servo_flag6.dutylast-servocfg->Servospeed_6;
			}

		}
		if(timer_up6==1)
		{
			timer_up6=0;
			servo_flag6.count++;
			if(servo_flag6.dutynew>servo_flag6.dutylast)
			{
				servo_flag6.duty1=(servo_flag6.dutyx*SPEED_CTR)/servo_flag6.timenew;
				servo_flag6.dutynow=servo_flag6.duty1*servo_flag6.count+servo_flag6.dutylast;
				Servo_control(SERVO_6,servo_flag6.dutynow);
				
				if(servo_flag6.dutynow>servo_flag6.dutynew||servo_flag6.dutynow==servo_flag6.dutynew)
				{
					Servo_control(SERVO_6,servo_flag6.dutynew);
					servo_flag6.dutylast=servo_flag6.dutynew;
					servo_flag6.dutynow=servo_flag6.dutynew;
					servo_flag6.count=0;
					timer_up6=0;
				}
			}
			else if(servo_flag6.dutynew<servo_flag6.dutylast)
			{
				
				servo_flag6.duty1=(servo_flag6.dutyx*SPEED_CTR)/servo_flag6.timenew;
				servo_flag6.dutynow=servo_flag6.dutylast-servo_flag6.duty1*servo_flag6.count;
				Servo_control(SERVO_6,servo_flag6.dutynow);
				
				if(servo_flag6.dutynow<servo_flag6.dutynew||servo_flag6.dutynow==servo_flag6.dutynew)
				{
					Servo_control(SERVO_6,servo_flag6.dutynew);
					servo_flag6.dutylast=servo_flag6.dutynew;
					servo_flag6.dutynow=servo_flag6.dutynew;
					servo_flag6.count=0;
					timer_up6=0;
				}
			}
			else
			{

			}
			servo_now->Servonow_6=servo_flag6.dutynow;//������ĵ�ǰֵ���ݳ�ȥ��
		}
}




/****************************************************

��pca9685ָ����ַд��һ������

��ڲ�����
				WriteAddr  :д�����ݵ�Ŀ�ĵ�ַ    
				DataToWrite:Ҫд�������

****************************************************/
void pca9685_WriteOneByte(u8 WriteAddr,u8 DataToWrite)
{				   	  	    																 
    IIC_Start();  
		IIC_Send_Byte(0X80);	    //����д����

	if(IIC_Wait_Ack()==0)
	{
//	LCD_ShowString(60,70,200,16,16,"Yes");	
	}
	else
	{
	//	LCD_ShowString(60,70,200,16,16,"No");	
	}
	  IIC_Send_Byte(WriteAddr);

if(IIC_Wait_Ack()==0)
	{
//	LCD_ShowString(60,90,200,16,16,"Yes");	
	}
	else
	{
//		LCD_ShowString(60,90,200,16,16,"No");	
	}
	
	  IIC_Send_Byte(DataToWrite);     //�����ֽ�							   
 

if(IIC_Wait_Ack()==0)
	{
//	LCD_ShowString(60,110,200,16,16,"Yes");	
	}
	else
	{
//		LCD_ShowString(60,110,200,16,16,"No");	
	}
		
    IIC_Stop();//����һ��ֹͣ���� 
	  delay_ms(10);	 
}

/****************************************************

��pca9685�����ָ����ַ��ʼд��ָ������������
		
��ڲ�����
					WriteAddr :��ʼд��ĵ�ַ
					pBuffer   :���������׵�ַ
					NumToWrite:Ҫд�����ݵĸ���

****************************************************/
void pca9685_Write(u8 WriteAddr,u8 *pBuffer,u8 NumToWrite)
{
	while(NumToWrite--)
	{
		pca9685_WriteOneByte(WriteAddr,*pBuffer);
		WriteAddr++;
		pBuffer++;
	}
}
